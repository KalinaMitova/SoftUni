const User = require('../models/User');
const Team = require('../models/Team');
const Project = require('../models/Project');

module.exports = {
    createTeamGet: async (req, res) => {
        res.render('admin/create-team');
    },
    createTeamPost: async (req, res) => {
        try {
            const name = req.body.name;
            if (!name) {
                res.locals.globalError = "Name is required!";
                res.render('admin/create-team', req.body);
                return;
            }

            const team = await Team.create({
                name
            });

            if (!team) {
                res.locals.globalError = "Something went wrong!";
                res.render('admin/create-team', req.body);
                return;
            }

            res.redirect('/');
        } catch (error) {
            res.locals.globalError = "Something went wrong!";
            res.render('home/index');
        }
    },
    createProjectGet: async (req, res) => {
        res.render('admin/create-project');
    },
    createProjectPost: async (req, res) => {
        try {
            const name = req.body.name;
            if (!name) {
                res.locals.globalError = "Name is required!";
                res.render('admin/create-project', req.body);
                return;
            }

            const description = req.body.description;
            if (!description) {
                res.locals.globalError = "Description is required!";
                res.render('admin/create-project', req.body);
                return;
            }

            const project = await Project.create({
                name,
                description,
            });

            if (!project) {
                res.locals.globalError = "Something went wrong!";
                res.render('admin/create-project', req.body);
                return;
            }

            res.redirect('/');
        } catch (error) {
            res.locals.globalError = "Something went wrong!";
            res.render('home/index');
        }
    },
    projectDistributeGet: async (req, res) => {
        res.render('admin/projects-admin', await getTeamsAndProjects());
    },
    projectDistributePost: async (req, res) => {
        try {
            const teamId = req.body.teamId;
            const projectId = req.body.projectId;

            const team = await Team.findById(teamId);
            if (!team) {
                res.locals.globalError = `Team with id '${teamId}' not found! Please try again.`;
                res.render('admin/projects-admin', await getTeamsAndProjects());
                return;
            }

            const project = await Project.findById(projectId);
            if (!project) {
                res.locals.globalError = `Project with id '${projectId}' not found! Please try again.`;
                res.render('admin/projects-admin', await getTeamsAndProjects());
                return;
            }

            if (project.team) {
                res.locals.globalError = `This project is already distributed!`;
                res.render('admin/projects-admin', await getTeamsAndProjects());
                return;
            }

            team.projects.push(project._id);
            project.team = team._id;

            await team.save();
            await project.save();

            res.redirect('/');
        } catch (error) {
            res.locals.globalError = "Something went wrong!";
            res.render('home/index');
        }
    },
    teamDistributeGet: async (req, res) => {
        res.render('admin/teams-admin', await getUsersAndTeams());
    },
    teamDistributePost: async (req, res) => {
        try {
            const userId = req.body.userId;
            const teamId = req.body.teamId;

            const user = await User.findById(userId);
            if (!user) {
                res.locals.globalError = `User with id '${userId}' not found! Please try again.`;
                res.render('admin/teams-admin', await getUsersAndTeams());
                return;
            }

            const team = await Team.findById(teamId);
            if (!team) {
                res.locals.globalError = `Team with id '${teamId}' not found! Please try again.`;
                res.render('admin/teams-admin', await getUsersAndTeams());
                return;
            }

            if (user.teams && user.teams.indexOf(team._id) > -1) {
                res.locals.globalError = `This user is already member of this team!`;
                res.render('admin/teams-admin', await getUsersAndTeams());
                return;
            }

            team.members.push(user._id);
            user.teams.push(team._id);

            await team.save();
            await user.save();

            res.redirect('/');
        } catch (error) {
            res.locals.globalError = "Something went wrong!";
            res.render('home/index');
        }
    },
};

async function getTeamsAndProjects() {
    const teams = await Team.find({});
    const projects = await Project.find({
        team: {
            $exists: false
        }
    });

    return {
        teams,
        projects
    };
}

async function getUsersAndTeams() {
    const users = await User.find({});
    const teams = await Team.find({});

    return {
        users,
        teams
    };
}