﻿namespace Employees.Data
{
    public class Configuration
    {
        public static string ConnectionString => @"Server=(LocalDb)\MSSQLLocalDb;Database=EmployeesDb;Integrated Security=True";
    }
}
