﻿namespace Employees.Services.Contracts
{
    public interface IDatabaseInitializerService
    {
        void InitializeDatabase();
    }
}
