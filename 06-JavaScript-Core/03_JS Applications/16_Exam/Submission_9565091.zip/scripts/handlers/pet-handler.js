handlers.petListings = function (ctx) {
    if (!auth.isAuth()) {
        notify.showError("You are not logged in. Please log in to view pet listings.");
        this.redirect("#/login");
        return;
    }

    let filter = ctx.params.filter;

    if (filter === undefined) {
        filter = "All";
    }

    petService.listAllByFilter(filter)
        .then(function (data) {
            data = data.sort((a, b) => {
                return b.likes - a.likes;
            });
            handlers.renderView(ctx, 'templates/pet/pet-listings.hbs', {
                pets: data
            });
        }).catch(notify.handleError);
};

handlers.myPets = function (ctx) {
    if (!auth.isAuth()) {
        notify.showError("You are not logged in. Please log in to view pet listings.");
        this.redirect("#/login");
        return;
    }

    petService.listMyPets()
        .then(function (data) {
            handlers.renderView(ctx, 'templates/pet/my-pets.hbs', {
                pets: data
            });
        }).catch(notify.handleError);
};

handlers.getCreatePet = function (ctx) {
    if (!auth.isAuth()) {
        notify.showError("You are not logged in. Please log in to view pet listings.");
        this.redirect("#/login");
        return;
    }

    handlers.renderView(ctx, 'templates/pet/create-pet.hbs');
};

handlers.postCreatePet = function (ctx) {
    if (!auth.isAuth()) {
        notify.showError("You are not logged in. Please log in to view pet listings.");
        this.redirect("#/login");
        return;
    }

    let data = {
        name: ctx.params.name,
        description: ctx.params.description,
        imageURL: ctx.params.imageURL,
        category: ctx.params.category,
        likes: 0
    };

    petService.createPet(data)
        .then(function () {
            notify.showInfo("Pet created.");
            ctx.redirect("#/petListings");
        }).catch(notify.handleError);
};

handlers.likePet = function (ctx) {
    if (!auth.isAuth()) {
        notify.showError("You are not logged in. Please log in to view pet listings.");
        this.redirect("#/login");
        return;
    }
    
    let petId = ctx.params.id;
    
    petService.getById(petId)
        .then(function (data) {
            let userId = sessionStorage.getItem("userId");

            if (data._acl.creator === userId) {
                notify.showError("This pet is yours and can't pet him.");
                ctx.redirect("#/petListings");
                return;
            }

            data.likes = +data.likes + 1;

            petService.edit(data)
                .then(function () {
                    notify.showInfo("Pet liked.");
                    ctx.redirect("#/");
                }).catch(notify.handleError);
        }).catch(notify.handleError);
};

handlers.getDetailsPet = function (ctx) {
    if (!auth.isAuth()) {
        notify.showError("You are not logged in. Please log in to view pet listings.");
        this.redirect("#/login");
        return;
    }

    let petId = ctx.params.id;

    petService.getById(petId)
        .then(function (data) {
            let userId = sessionStorage.getItem("userId");

            if (data._acl.creator === userId) {
                handlers.renderView(ctx, 'templates/pet/details-my-pet.hbs', data);
            } else {
                handlers.renderView(ctx, 'templates/pet/details-other-pet.hbs', data);
            }
        }).catch(notify.handleError);
};

handlers.getEditPet = function (ctx) {
    if (!auth.isAuth()) {
        notify.showError("You are not logged in. Please log in to view pet listings.");
        this.redirect("#/login");
        return;
    }

    let petId = ctx.params.id;

    petService.getById(petId)
        .then(function (data) {

            let userId = sessionStorage.getItem("userId");

            if (data._acl.creator !== userId) {
                notify.showError("This pet is not yours.");
                ctx.redirect("#/petListings");
                return;
            }

            handlers.renderView(ctx, 'templates/pet/details-my-pet.hbs', data);

        }).catch(notify.handleError);
};

handlers.postEditPet = function (ctx) {
    if (!auth.isAuth()) {
        notify.showError("You are not logged in. Please log in to view pet listings.");
        this.redirect("#/login");
        return;
    }

    let petId = ctx.params.id;
    let description = ctx.params.description;

    petService.getById(petId)
        .then(function (data) {
            data.description = description;

            petService.edit(data)
                .then(function () {
                    notify.showInfo("Updated successfully!");
                    ctx.redirect(`#/pet/myPets`);
                });
        }).catch(notify.handleError);
};

handlers.getDeletePet = function (ctx) {
    if (!auth.isAuth()) {
        notify.showError("You are not logged in. Please log in to view pet listings.");
        this.redirect("#/login");
        return;
    }

    let petId = ctx.params.id;

    petService.getById(petId)
        .then(function (data) {
            let userId = sessionStorage.getItem("userId");

            if(data._acl.creator !== userId) {
                notify.showError("This pet is not yours.");
                ctx.redirect("#/petListings");
                return;
            }

            handlers.renderView(ctx, 'templates/pet/delete-pet.hbs', data);
        }).catch(notify.handleError);
};

handlers.postDeletePet = function (ctx) {
    if (!auth.isAuth()) {
        notify.showError("You are not logged in. Please log in to view pet listings.");
        this.redirect("#/login");
        return;
    }

    let petId = ctx.params.id;

    petService.getCreator(petId)
        .then(function (data) {
            let creatorId = data._acl.creator;
            let userId = sessionStorage.getItem("userId");

            if (userId !== creatorId) {
                notify.showError("This pet is not yours.");
                ctx.redirect("#/petListings")
                return;
            }

            petService.removeById(petId)
                .then(function () {
                    notify.showInfo("Pet removed successfully!");
                    ctx.redirect("#/petListings");
                });
        }).catch(notify.handleError);
};