handlers.renderView = function (ctx, bodyPath, data) {
    data = data || {};
    data.isAuth = auth.isAuth();
    
    if (data.isAuth) {
        data.username = sessionStorage.getItem("username");
    }

    ctx.loadPartials({
        "header": 'templates/common/header.hbs',
        "body": bodyPath,
        "footer": "templates/common/footer.hbs"
    }).then(function () {
        this.partial('templates/main.hbs', data)
    });
}

handlers.getHomePage = function (ctx) {
    if (auth.isAuth()) {
        this.redirect("#/petListings");
    } else {
        handlers.renderView(ctx, 'templates/home.hbs');
    }
};

handlers.getRegister = function (ctx) {
    if (auth.isAuth()) {
        notify.showError('You are logged in. Please logout first!');
        return;
    }

    handlers.renderView(ctx, 'templates/auth-forms/register-form.hbs');
};

handlers.registerUser = function (ctx) {
    if (auth.isAuth()) {
        notify.showError('You are logged in. Please logout first!');
        return;
    }

    const username = ctx.params.username;
    const password = ctx.params.password;

    if (username.length < 3) {
        notify.showError('Username must be at least 3 symbols');
    } else if (password.length < 6) {
        notify.showError('Password must be at least 6 symbols');
    } else {
        auth.register(username, password)
            .then((userData) => {
                auth.saveSession(userData);
                notify.showInfo('User registration successful.');
                ctx.redirect('#/petListings');
            })
            .catch(notify.handleError)
    }
};

handlers.getLogin = function (ctx) {
    if (auth.isAuth()) {
        notify.showError('You are logged in. Please logout first!');
        return;
    }

    handlers.renderView(ctx, 'templates/auth-forms/login-form.hbs');
};

handlers.loginUser = function (ctx) {
    if (auth.isAuth()) {
        notify.showError('You are logged in. Please logout first!');
        return;
    }

    const username = ctx.params.username;
    const password = ctx.params.password;

    if (username.length < 3) {
        notify.showError('Username must be at least 3 symbols');
    } else if (password.length < 6) {
        notify.showError('Password must be at least 6 symbols');
    } else {
        auth.login(username, password)
            .then((userData) => {
                auth.saveSession(userData);
                notify.showInfo('Login successful.');
                ctx.redirect('#/petListings');
            })
            .catch(notify.handleError);
    }
};

handlers.logout = function (ctx) {
    if (!auth.isAuth()) {
        notify.showError('You are not logged in. Please login first!');
        return;
    }

    auth.logout()
        .then(() => {
            sessionStorage.clear();
            notify.showInfo('Logout successful.');
            ctx.redirect('#/');
        })
};