const handlers = {};

$(() => {
    // Define routes here using Sammy.js
    const app = Sammy('#container', function () {
        this.use('Handlebars', 'hbs');

        this.get('index.html', handlers.getHomePage);
        this.get('#/', handlers.getHomePage);
        this.get('/', handlers.getHomePage);

        this.get('#/register', handlers.getRegister);
        this.post('#/register', handlers.registerUser);
        this.get('#/login', handlers.getLogin);
        this.post('#/login', handlers.loginUser);
        this.get('#/logout', handlers.logout);

        this.get('#/petListings', handlers.petListings);
        this.get('#/pet/myPets', handlers.myPets);

        this.get('#/pet/create', handlers.getCreatePet);
        this.post('#/pet/create', handlers.postCreatePet);
        
        this.get('#/pet/like/:id', handlers.likePet);

        this.get('#/pet/edit/:id', handlers.getEditPet);
        this.post('#/pet/edit/:id', handlers.postEditPet);
  
        this.get('#/pet/delete/:id', handlers.getDeletePet);
        this.post('#/pet/delete/:id', handlers.postDeletePet);
        
        this.get('#/pet/details/:id', handlers.getDetailsPet);      
    });

    app.run();
});