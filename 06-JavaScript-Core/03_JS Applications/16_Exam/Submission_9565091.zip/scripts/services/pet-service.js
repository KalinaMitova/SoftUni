let petService = (function() {

    const listAllByFilter = function(filter) {
        if(!(filter === "All" || filter === "Cat" ||
            filter === "Dog" || filter === "Parrot" ||
            filter === "Reptile" || filter === "Other")) {
            throw new Error("Invalid category!");
        }

        let userId = sessionStorage.getItem("userId");
        let endpoint = `pets?query={"_acl.creator":{"$ne":"${userId}"}`;

        if(filter !== "All") {
            endpoint += `,"category":"${filter}"`;
        }

        endpoint += '}&sort={"likes": -1}';

        return remote.get('appdata', endpoint, 'kinvey');
    };

    const listMyPets = function() {
        let userId = sessionStorage.getItem("userId");
        let endpoint = `pets?query={"_acl.creator":"${userId}"}`;

        return remote.get('appdata', endpoint, 'kinvey');
    }

    const createPet = function(data) {
        return remote.post('appdata', 'pets', 'kinvey', data);
    } 

    const getById = function(id) {
        return remote.get('appdata', `pets/${id}`, 'kinvey');
    }

    const edit = function(data) {
        const endpoint = `pets/${data._id}`;

        return remote.update('appdata', endpoint, 'kinvey', data);
    }

    const removeById = function(petId) {
        const endpoint = `pets/${petId}`;
        
        return remote.remove('appdata', endpoint, 'kinvey');
    };

    const getCreator = function(petId) {
        const endpoint = `pets/${petId}?fields=_acl`;

        return remote.get('appdata', endpoint, 'kinvey');
    };

    return {
        listAllByFilter,
        createPet,
        listMyPets,
        getById,
        edit,
        removeById,
        getCreator
    };
})();