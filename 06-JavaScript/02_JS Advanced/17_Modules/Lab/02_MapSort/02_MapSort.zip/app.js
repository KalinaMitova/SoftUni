let mapSort = require('./sortMap');

result.mapSort = mapSort;